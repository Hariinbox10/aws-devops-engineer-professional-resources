#!/bin/bash
chmod +x /tmp/kplabs
/tmp/kplabs > /tmp/kplabs-log.txt
