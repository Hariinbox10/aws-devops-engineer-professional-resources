#!/bin/bash
aws s3 cp s3://kplabs-myartifact/kplabs-demo02/kplabs /tmp/
